import React, { useState } from "react"; // Burada useState'i ekleyin
import Gender from "./components/chooseGender";
import Results from "./components/results";
import BasicInfo from "./components/basicInfo";
import SilhouetteInfo from "./components/silhouetteInfo";
import HipShape from "./components/hipShape";
import "./App.css";
function App() {
  const [isShowGender, setIsShowGender] = useState(true);
  const [isShowBasic, setIsShowBasic] = useState(false);
  const [isShowSilhouette, setIsShowSilhouette] = useState(false);
  const [isShowHipShape, setIsShowHipShape] = useState(false);
  const [isShowResults, setIsShowResults] = useState(false);
  const [gender, setGender] = useState("");
  const [inputs, setInputs] = useState({
    height: "",
    weight: "",
    age: "",
  });
  const [silhouetteButtonId, setSilhouetteButtonId] = useState("");
  const [hipButtonId, setHipButtonId] = useState("");

  console.log(gender);

  return (
    <>
      <h2 className="header">FIND MY SIZE</h2>
      {isShowGender && (
        <Gender
          gender={gender}
          setIsShowGender={setIsShowGender}
          setGender={setGender}
          setIsShowBasic={setIsShowBasic}
        />
      )}
      {isShowBasic && (
        <BasicInfo
          inputs={inputs}
          setInputs={setInputs}
          setIsShowBasic={setIsShowBasic}
          setIsShowSilhouette={setIsShowSilhouette}
        />
      )}
      {isShowSilhouette && (
        <SilhouetteInfo
          setIsShowSilhouette={setIsShowSilhouette}
          setIsShowHipShape={setIsShowHipShape}
          setSilhouetteButtonId={setSilhouetteButtonId}
          silhouetteButtonId={silhouetteButtonId}
        />
      )}
      {isShowHipShape && (
        <HipShape
          setIsShowHipShape={setIsShowHipShape}
          setIsShowResults={setIsShowResults}
          setHipButtonId={setHipButtonId}
          hipButtonId={hipButtonId}
        />
      )}

      {isShowResults && (
        <Results
          gender={gender}
          inputs={inputs}
          silhouetteButtonId={silhouetteButtonId}
          hipButtonId={hipButtonId}
        />
      )}
    </>
  );
}

export default App;
