const calculateSize = ({
  gender,
  height,
  weight,
  age,
  abdominalType,
  shoulderType,
}) => {
  // Uygunsuz değerleri kontrol et
  if (
    height < 140 ||
    height > 220 ||
    weight < 40 ||
    weight > 200 ||
    age < 10 ||
    age > 100
  ) {
    return "Maalesef uygun beden bulunamadı";
  }

  let size = "";

  // Kadınlar için tahmin algoritması
  if (gender === "Female") {
    if (
      height >= 150 &&
      height <= 160 &&
      weight >= 40 &&
      weight <= 50 &&
      abdominalType === "flat" &&
      shoulderType === "narrow"
    ) {
      size = "XS";
    } else if (
      height >= 160 &&
      height <= 170 &&
      weight >= 50 &&
      weight <= 65 &&
      abdominalType === "flat" &&
      shoulderType === "medium"
    ) {
      size = "S";
    } else if (
      height >= 170 &&
      height <= 180 &&
      weight >= 60 &&
      weight <= 75 &&
      abdominalType === "medium" &&
      shoulderType === "medium"
    ) {
      size = "M";
    } else if (
      height >= 175 &&
      height <= 185 &&
      weight >= 70 &&
      weight <= 85 &&
      abdominalType === "medium" &&
      shoulderType === "wide"
    ) {
      size = "L";
    } else if (
      height >= 180 &&
      height <= 190 &&
      weight >= 80 &&
      weight <= 95 &&
      abdominalType === "bulge" &&
      shoulderType === "wide"
    ) {
      size = "XL";
    } else if (
      height > 190 &&
      weight > 95 &&
      abdominalType === "bulge" &&
      shoulderType === "wide"
    ) {
      size = "XXL";
    } else {
      size = "M"; // Genel varsayılan beden
    }
  }

  // Erkekler için tahmin algoritması
  if (gender === "Male") {
    if (
      height >= 160 &&
      height <= 170 &&
      weight >= 50 &&
      weight <= 65 &&
      abdominalType === "flat" &&
      shoulderType === "narrow"
    ) {
      size = "XS";
    } else if (
      height >= 170 &&
      height <= 180 &&
      weight >= 60 &&
      weight <= 75 &&
      abdominalType === "flat" &&
      shoulderType === "medium"
    ) {
      size = "S";
    } else if (
      height >= 180 &&
      height <= 185 &&
      weight >= 70 &&
      weight <= 85 &&
      abdominalType === "medium" &&
      shoulderType === "medium"
    ) {
      size = "M";
    } else if (
      height >= 185 &&
      height <= 190 &&
      weight >= 80 &&
      weight <= 95 &&
      abdominalType === "medium" &&
      shoulderType === "wide"
    ) {
      size = "L";
    } else if (
      height >= 190 &&
      weight >= 90 &&
      abdominalType === "bulge" &&
      shoulderType === "wide"
    ) {
      size = "XL";
    } else if (
      height > 195 &&
      weight > 100 &&
      abdominalType === "bulge" &&
      shoulderType === "wide"
    ) {
      size = "XXL";
    } else {
      size = "L"; // Genel varsayılan beden
    }
  }

  return size;
};

// Örnek kullanım:
const userMeasurements = {
  gender: "Male",
  height: 185,
  weight: 85,
  age: 25,
  abdominalType: "medium",
  shoulderType: "medium",
};

const sizePrediction = calculateSize(userMeasurements);
console.log(sizePrediction); // L

export default calculateSize;
