import Card from "../UI/Card";
import SilhouetteInfoItem from "./silhouetteInfoItem";
import "./styles/images.css";
function silhouetteInfo({
  setIsShowSilhouette,
  setIsShowHipShape,
  setSilhouetteButtonId,
  silhouetteButtonId,
}) {
  const flatClick = () => {
    setSilhouetteButtonId("flat");
  };
  const mediumClick = () => {
    setSilhouetteButtonId("medium");
  };
  const bulgeClick = () => {
    setSilhouetteButtonId("bulge");
  };
  console.log(silhouetteButtonId);
  const clickNext = () => {
    if (silhouetteButtonId != "") {
      setIsShowSilhouette(false);
      setIsShowHipShape(true);
    } else {
      alert("Lütfen Bir Seçim Yapınız...");
    }
  };
  return (
    <Card className="images">
      <h3 className="title">
        Please Select the Most Suitable Abdominal Type for You
      </h3>
      <SilhouetteInfoItem silhouetteButtonId={silhouetteButtonId} />
      <div className="imagesButtons">
        <button className="btn" onClick={flatClick}>
          Flat
        </button>
        <button className="btn" onClick={mediumClick}>
          Medium
        </button>
        <button className="btn" onClick={bulgeClick}>
          Bulge
        </button>
      </div>
      <button className="nextBtn" onClick={clickNext}>
        Next
      </button>
    </Card>
  );
}

export default silhouetteInfo;
