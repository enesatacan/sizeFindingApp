import ImagesData from "../data";
import "./styles/images.css";

function SilhouetteInfoItem({ silhouetteButtonId }) {
  const defaultImage = ImagesData.male.silhouette[0];

  const selectedImage =
    ImagesData.male.silhouette.find((item) => item.id === silhouetteButtonId) ||
    defaultImage;

  return (
    <div>
      <img className="imageItem" src={selectedImage.img} alt="hipShape" />
    </div>
  );
}

export default SilhouetteInfoItem;
