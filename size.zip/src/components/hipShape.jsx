import { useState } from "react";
import Card from "../UI/Card";
import HipShapeItem from "./hipShapeItem";
import ImagesData from "../data"; // Move this import to the appropriate place if necessary
import "./styles/images.css";

function HipShape({
  setIsShowHipShape,
  setIsShowResults,
  setHipButtonId,
  hipButtonId,
}) {
  // Component names should be capitalized

  const narrowClick = () => {
    setHipButtonId("narrow");
  };
  const mediumClick = () => {
    setHipButtonId("medium");
  };
  const wideClick = () => {
    setHipButtonId("wide");
  };

  console.log(hipButtonId);

  const clickSize = () => {
    if (hipButtonId != "") {
      setIsShowHipShape(false);
      setIsShowResults(true);
    } else {
      alert("Lütfen Bir Seçim Yapınız...");
    }
  };

  return (
    // Make sure to return the JSX
    <Card className={"images"}>
      <h3 className="title">
        Please select the most suitable shoulder type for you
      </h3>
      <HipShapeItem hipButtonId={hipButtonId} />
      <div className="imagesButtons">
        <button className="btn" onClick={narrowClick}>
          Narrow
        </button>
        <button className="btn" onClick={mediumClick}>
          Medium
        </button>
        <button className="btn" onClick={wideClick}>
          Wide
        </button>
      </div>
      <button className="nextBtn" onClick={clickSize}>
        Find My Size
      </button>
    </Card>
  );
}

export default HipShape;
