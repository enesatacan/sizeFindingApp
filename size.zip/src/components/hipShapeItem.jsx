import ImagesData from "../data";
import "./styles/images.css";

function hipShapeItem({ hipButtonId }) {
  const defaultImage = ImagesData.male.hipShape[0];

  const selectedImage =
    ImagesData.male.hipShape.find((item) => item.id === hipButtonId) ||
    defaultImage;

  return (
    <div>
      <img className="imageItem" src={selectedImage.img} alt="hipShape" />
    </div>
  );
}

export default hipShapeItem;
