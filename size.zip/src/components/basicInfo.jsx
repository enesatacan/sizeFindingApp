import "./styles/basicInfo.css";
import Card from "../UI/Card";

function basicInfo({ inputs, setInputs, setIsShowSilhouette, setIsShowBasic }) {
  const { height, weight, age } = inputs;
  const handleNext = (e) => {
    e.preventDefault();
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setInputs((prevInputs) => ({
      ...prevInputs,
      [name]: value,
    }));
  };
  const clickNext = () => {
    if (height !== "" && weight !== "" && age !== "") {
      if (
        height >= 140 &&
        height <= 220 &&
        weight >= 40 &&
        weight <= 180 &&
        age >= 10 &&
        age <= 90
      ) {
        setIsShowBasic(false);
        setIsShowSilhouette(true);
      } else {
        alert("Please Enter Information Within the Valid Value Range..");
      }
    } else {
      alert("Please Enter All Values...");
    }
  };
  return (
    <Card>
      <h3 className="title">
        We Will Calculate Your Ideal Size According to Your Measurements.
      </h3>
      <form className="form" onSubmit={handleNext}>
        <label className="label">Height</label>
        <input
          required
          className="input"
          name="height"
          type="number"
          onChange={handleChange}
        />
        <label className="label">Weight</label>
        <input
          required
          className="input"
          name="weight"
          type="number"
          onChange={handleChange}
        />
        <label className="label">Age</label>
        <input
          className="input"
          name="age"
          type="number"
          onChange={handleChange}
        />
      </form>
      <button className="nextBtn" onClick={clickNext}>
        Next
      </button>
    </Card>
  );
}

export default basicInfo;
