import Card from "../UI/Card";
import sizeData from "../sizeData";
import "../UI/styles/Card.css";

function Results({ gender, inputs, silhouetteButtonId, hipButtonId }) {
  const getSizeFind = (height, weight, age, belly, shoulder) => {
    const sizeDataForGender =
      gender === "male" ? sizeData.male : sizeData.female;

    const result = sizeDataForGender.find(
      (item) =>
        height >= item.heightRange.min &&
        height <= item.heightRange.max &&
        weight >= item.weightRange.min &&
        weight <= item.weightRange.max &&
        age >= item.ageRange.min &&
        age <= item.ageRange.max &&
        item.belly === belly &&
        item.shoulder === shoulder
    );

    console.log("Result: ", result);
    return result ? result.size : "No suitable size found";
  };

  // Kullanıcıdan gelen verileri kontrol et
  if (
    inputs.height < 140 ||
    inputs.height > 220 ||
    inputs.weight < 40 ||
    inputs.weight > 180 ||
    inputs.age < 10 ||
    inputs.age > 90
  ) {
    return (
      <div className="results">
        <Card>
          <div style={{ color: "#42615c", fontSize: "24px" }}>
            No size found!
          </div>
        </Card>
      </div>
    );
  }

  // Uygun bedeni bul
  const sizeResult = getSizeFind(
    inputs.height,
    inputs.weight,
    inputs.age,
    silhouetteButtonId,
    hipButtonId
  );

  return (
    <div className="results">
      <Card>
        <div style={{ color: "#42615c", fontSize: "24px" }}>
          The Most Suitable Size for You: <br /> <strong>"{sizeResult}"</strong>
        </div>
      </Card>
      <h3 className="title">Information:</h3>
      <div>
        <div>
          <p>Gender: {gender}</p>
        </div>
        <div>
          <span>Measurements:</span>
          <div>
            <p>Height: {inputs.height}</p>
            <p>Weight: {inputs.weight}</p>
            <p>Age: {inputs.age}</p>
          </div>
        </div>
        <p>Abdominal Tipi: {silhouetteButtonId}</p>
        <p>Shoulder Tipi: {hipButtonId}</p>
      </div>
      <hr />
    </div>
  );
}

export default Results;
