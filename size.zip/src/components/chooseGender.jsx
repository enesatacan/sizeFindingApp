import Card from "../UI/Card";
import "./styles/gender.css";

function chooseGender({ gender, setIsShowGender, setGender, setIsShowBasic }) {
  const chooseMale = () => {
    setGender("Male");
  };
  const chooseFemale = () => {
    setGender("Female");
  };
  const clickNext = () => {
    if (gender === "Female" || gender === "Male") {
      console.log("seçti");
      setIsShowGender(false);
      setIsShowBasic(true);
    } else {
      alert("Make a Choice......");
    }
  };
  return (
    <Card className="genderCard">
      <h3 className="title">Please Select Gender</h3>
      <div className="gender">
        <button className="btn" onClick={chooseMale}>
          Male
        </button>
        <button className="btn" onClick={chooseFemale}>
          Female
        </button>
      </div>
      <button className="nextBtn" onClick={clickNext}>
        Next
      </button>
    </Card>
  );
}

export default chooseGender;
