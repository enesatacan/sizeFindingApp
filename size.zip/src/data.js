const imagesData = {
  male: {
    silhouette: [
      {
        id: "flat",
        img: "https://static.pullandbear.net/2/static2/itxwebstandard/images/recomendador_tallas/Hombre_Vientre_Plano.png?20241011132700",
      },
      {
        id: "medium",
        img: "https://static.pullandbear.net/2/static2/itxwebstandard/images/recomendador_tallas/Hombre_Vientre_Medio.png?20241011132700",
      },
      {
        id: "bulge",
        img: "https://static.pullandbear.net/2/static2/itxwebstandard/images/recomendador_tallas/Hombre_Vientre_Abultado.png?20241011132700",
      },
    ],
    hipShape: [
      {
        id: "narrow",
        img: "https://static.pullandbear.net/2/static2/itxwebstandard/images/recomendador_tallas/Hombre_Vientre_Abultado_Pecho_Recto.png?20241011132700",
      },
      {
        id: "medium",
        img: "https://static.pullandbear.net/2/static2/itxwebstandard/images/recomendador_tallas/Hombre_Vientre_Abultado_Pecho_Medio.png?20241011132700",
      },
      {
        id: "wide",
        img: "https://static.pullandbear.net/2/static2/itxwebstandard/images/recomendador_tallas/Hombre_Vientre_Abultado_Pecho_Ancho.png?20241011132700",
      },
    ],
  },
  female: [],
};

export default imagesData;
